HolaHola coordination runtime onboarding helper

This package does not install or replace the Coordinator V2 execution runtime.
Use an independently installed, trusted Node.js 20+ runtime.
Verify the package/source revision through your approved source publication.
A manifest from the same untrusted download is not an independent trust anchor.
A development package with sourceDirty=true is not an approved release.

Run: node bin/holahola-onboarding.mjs --help
SDK: import { createRuntimeOpenAIResponsesClient } from "./lib/runtime-onboarding-sdk.mjs".
Supply your own already-authorized OpenAI SDK instance; this helper never supplies its API key.
Commands and arguments contain only endpoint and non-secret runtime references.
No credential-export command exists. Do not add secrets to shell commands.
Windows credential/key custody uses the scripts/ helper and DPAPI CurrentUser.
Windows helper child uses RemoteSigned only for that process; no saved policy changes.
Organizational Group Policy and downloaded-script restrictions remain enforced.
Blocked helpers fail closed; do not use Bypass or automatically unblock files.
Keep the bin/ and scripts/ directories together.

The OS secret store must be available. Unsupported stores fail closed.
No script is downloaded and evaluated at setup time.
