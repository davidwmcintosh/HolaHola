# Ownership CLI repair transfer

This archive contains the corrected CLI/client and their two unchanged local
dependencies, copied from the main workspace. SHA256SUMS and
source-provenance.json identify the exact source bytes and local Git revision.
This archive does not imply that the revision is available on GitHub.
Its minimal package.json preserves the source module format outside the main
repository. It declares no dependencies or install scripts.

No credentials, private keys, receipt data, task artifacts, episode records,
node_modules, or runtime configuration are included.

## Use before ownership is established

1. Extract into a private temporary directory OUTSIDE the task checkout.
2. From the extracted ownership-cli-repair directory, verify SHA256SUMS:

   sha256sum -c SHA256SUMS

3. Inspect the source. It is the approved standalone proof-vs-runtime-grant
   repair, not an ownership bypass. The four modules need only Node built-ins
   and the existing TypeScript runner.
4. Return to the ORIGINAL task checkout as the working directory. Do not alter
   the task artifact, actor, original private key, TMPDIR, credentials, or
   server endpoint.
5. Repeat the original ownership prove command, replacing ONLY the script path
   with the absolute path to the extracted
   ownership-cli-repair/server/scripts/task-ownership-cli.ts.
   Use the already-installed runner; do not install dependencies to run this
   transfer. For an existing local tsx installation:

   npx --no-install tsx /ABSOLUTE/EXTRACTED/PATH/ownership-cli-repair/server/scripts/task-ownership-cli.ts prove --task-ref 1437 --actor ORIGINAL_ACTOR --receipt-id ORIGINAL_APPROVED_RECEIPT --app-url ORIGINAL_ENDPOINT

   Replace the uppercase placeholders using the original approved command.
   These are not new credentials or authority.

The external script still reads the task artifact from process.cwd(), and
loads the original task key using the unchanged key-custody module. It does not
need to overwrite repository files before ownership proof.

Proceed with task work only if the proof command returns isolated_agent with
exit code zero. Do not bypass unknown_stop or classify .git alone as ownership.
If the receipt expired, stop and request a new challenge and founder approval.
If the original private key is missing, do not substitute another process's
key or reuse the old approval with a new key.

## Contents

- server/scripts/task-ownership-cli.ts — repaired standalone CLI.
- server/services/task-ownership-client.ts — distinct proof-only helper;
  the existing runtime helper still requires an execution grant.
- server/services/task-ownership-service.ts — unchanged fail-closed classifier.
- server/services/task-ownership-key-custody.ts — unchanged local key custody.

No server authentication, grant issuance, Antigravity execution checks,
Episode 34 content, or task assignment is changed by this transfer.